import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';
import * as _angular_forms_signals from '@angular/forms/signals';
import { FormCheckboxControl, FormValueControl, ValidationError } from '@angular/forms/signals';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatSelectChange } from '@angular/material/select';
import { MatRadioChange } from '@angular/material/radio';

declare class TpAvatar {
    src: _angular_core.InputSignal<string | null>;
    alt: _angular_core.InputSignal<string>;
    size: _angular_core.InputSignalWithTransform<number, unknown>;
    tooltipTitle: _angular_core.InputSignal<string | null>;
    disabled: _angular_core.InputSignal<boolean>;
    onClick: _angular_core.OutputEmitterRef<MouseEvent>;
    private readonly failedSrc;
    protected readonly hasImage: _angular_core.Signal<boolean>;
    protected handleImageError(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpAvatar, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpAvatar, "tp-avatar", never, { "src": { "alias": "src"; "required": false; "isSignal": true; }; "alt": { "alias": "alt"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "tooltipTitle": { "alias": "tooltipTitle"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "onClick": "onClick"; }, never, never, true, never>;
}

declare class TpBellNotification {
    count: _angular_core.InputSignalWithTransform<number, unknown>;
    ariaLabel: _angular_core.InputSignal<string>;
    tooltipTitle: _angular_core.InputSignal<string | null>;
    disabled: _angular_core.InputSignal<boolean>;
    onClick: _angular_core.OutputEmitterRef<MouseEvent>;
    protected readonly notificationCount: _angular_core.Signal<number>;
    protected readonly badgeText: _angular_core.Signal<string>;
    protected readonly accessibleLabel: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpBellNotification, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpBellNotification, "tp-bell-notification", never, { "count": { "alias": "count"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "tooltipTitle": { "alias": "tooltipTitle"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "onClick": "onClick"; }, never, never, true, never>;
}

declare const TP_COMPONENT_COLORS: readonly ["gray", "red", "pink", "amber", "orange", "yellow", "green", "emerald", "teal", "blue", "cyan", "purple", "violet", "indigo"];
type TpComponentColor = (typeof TP_COMPONENT_COLORS)[number];

type TpButtonColor = TpComponentColor;
type TpButtonVariant = 'filled' | 'outlined' | 'tonal';
declare class TpButton {
    color: _angular_core.InputSignal<"gray" | "red" | "pink" | "amber" | "orange" | "yellow" | "green" | "emerald" | "teal" | "blue" | "cyan" | "purple" | "violet" | "indigo">;
    variant: _angular_core.InputSignal<TpButtonVariant>;
    disabled: _angular_core.InputSignal<boolean>;
    fullWidth: _angular_core.InputSignal<boolean>;
    tooltipTitle: _angular_core.InputSignal<string | null>;
    width: _angular_core.InputSignal<string>;
    maxWidth: _angular_core.InputSignal<string>;
    height: _angular_core.InputSignal<string>;
    maxHeight: _angular_core.InputSignal<string>;
    fontSize: _angular_core.InputSignal<string>;
    fontWeight: _angular_core.InputSignal<string>;
    onClick: _angular_core.OutputEmitterRef<MouseEvent>;
    protected readonly buttonStyle: _angular_core.Signal<{
        '--tp-button-color': string;
        '--tp-button-contrast-color': string;
        '--tp-button-tonal-bg': string;
        width: string;
        maxWidth: string;
        height: string;
        maxHeight: string;
        fontSize: string;
        fontWeight: string;
    }>;
    protected readonly buttonClass: _angular_core.Signal<{
        'tp-button--filled': boolean;
        'tp-button--outlined': boolean;
        'tp-button--tonal': boolean;
    }>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpButton, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpButton, "tp-button", never, { "color": { "alias": "color"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; "tooltipTitle": { "alias": "tooltipTitle"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "maxWidth": { "alias": "maxWidth"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "maxHeight": { "alias": "maxHeight"; "required": false; "isSignal": true; }; "fontSize": { "alias": "fontSize"; "required": false; "isSignal": true; }; "fontWeight": { "alias": "fontWeight"; "required": false; "isSignal": true; }; }, { "onClick": "onClick"; }, never, ["*"], true, never>;
}

declare class TpCard {
    color: _angular_core.InputSignal<string>;
    textColor: _angular_core.InputSignal<string>;
    borderColor: _angular_core.InputSignal<string>;
    width: _angular_core.InputSignal<string>;
    maxWidth: _angular_core.InputSignal<string>;
    height: _angular_core.InputSignal<string>;
    maxHeight: _angular_core.InputSignal<string>;
    protected readonly cardStyle: _angular_core.Signal<{
        '--tp-card-color': string;
        '--tp-card-text-color': string;
        '--tp-card-border-color': string;
        width: string;
        maxWidth: string;
        height: string;
        maxHeight: string;
    }>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpCard, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpCard, "tp-card", never, { "color": { "alias": "color"; "required": false; "isSignal": true; }; "textColor": { "alias": "textColor"; "required": false; "isSignal": true; }; "borderColor": { "alias": "borderColor"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "maxWidth": { "alias": "maxWidth"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "maxHeight": { "alias": "maxHeight"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

type TpChipColor = TpComponentColor;
type TpChipSize = 'sm' | 'md' | 'lg';
type TpChipVariant = 'filled' | 'outlined' | 'tonal' | 'text';
declare class TpChip {
    color: _angular_core.InputSignal<"gray" | "red" | "pink" | "amber" | "orange" | "yellow" | "green" | "emerald" | "teal" | "blue" | "cyan" | "purple" | "violet" | "indigo">;
    size: _angular_core.InputSignal<TpChipSize>;
    variant: _angular_core.InputSignal<TpChipVariant>;
    tooltipTitle: _angular_core.InputSignal<string | null>;
    fontSize: _angular_core.InputSignal<string | null>;
    fontWeight: _angular_core.InputSignal<string | null>;
    protected readonly chipStyle: _angular_core.Signal<{
        '--tp-chip-color': string;
        '--tp-chip-label-color': string;
        '--tp-chip-tonal-bg': string;
        fontSize: string | null;
        fontWeight: string | null;
    }>;
    protected readonly chipClass: _angular_core.Signal<{
        [x: string]: boolean;
    }>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpChip, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpChip, "tp-chip", never, { "color": { "alias": "color"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "tooltipTitle": { "alias": "tooltipTitle"; "required": false; "isSignal": true; }; "fontSize": { "alias": "fontSize"; "required": false; "isSignal": true; }; "fontWeight": { "alias": "fontWeight"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class TpCheckbox implements FormCheckboxControl {
    checked: _angular_core.ModelSignal<boolean>;
    touched: _angular_core.ModelSignal<boolean>;
    disabled: _angular_core.InputSignal<boolean>;
    indeterminate: _angular_core.InputSignal<boolean>;
    required: _angular_core.InputSignal<boolean>;
    name: _angular_core.InputSignal<string>;
    nativeValue: _angular_core.InputSignal<string>;
    ariaLabel: _angular_core.InputSignal<string | null>;
    tabIndex: _angular_core.InputSignal<number>;
    protected updateChecked(event: MatCheckboxChange): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpCheckbox, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpCheckbox, "tp-checkbox", never, { "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "indeterminate": { "alias": "indeterminate"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "nativeValue": { "alias": "nativeValue"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "tabIndex": { "alias": "tabIndex"; "required": false; "isSignal": true; }; }, { "checked": "checkedChange"; "touched": "touchedChange"; }, never, ["*"], true, never>;
}

declare const TP_DEFAULT_MIN_DATE: Date;
declare const TP_DEFAULT_MAX_DATE: Date;
declare function createTpDefaultMinDate(): Date;
declare function createTpDefaultMaxDate(): Date;
declare class TpDatePicker implements FormValueControl<Date | null> {
    value: _angular_core.ModelSignal<Date | null>;
    minDate: _angular_core.InputSignal<Date>;
    maxDate: _angular_core.InputSignal<Date>;
    disabled: _angular_core.InputSignal<boolean>;
    ariaLabel: _angular_core.InputSignal<string>;
    private readonly picker;
    private readonly scrollDispatcher;
    private readonly destroyRef;
    protected readonly startAt: _angular_core.Signal<Date>;
    constructor();
    open(): void;
    protected selectDate(date: Date | null): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpDatePicker, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpDatePicker, "tp-date-picker", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "minDate": { "alias": "minDate"; "required": false; "isSignal": true; }; "maxDate": { "alias": "maxDate"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

type TpValidationErrors = readonly ValidationError.WithOptionalFieldTree[];

type TpDateFormat = 'DD-MM-YYYY' | 'DD-MMM-YYYY' | 'MM-DD-YYYY' | 'YYYY-MM-DD';
declare class TpInputDatePicker implements FormValueControl<Date | null> {
    value: _angular_core.ModelSignal<Date | null>;
    touched: _angular_core.ModelSignal<boolean>;
    errors: _angular_core.InputSignal<TpValidationErrors>;
    invalid: _angular_core.InputSignal<boolean>;
    title: _angular_core.InputSignal<string>;
    placeholder: _angular_core.InputSignal<string>;
    dateFormat: _angular_core.InputSignal<TpDateFormat>;
    minDate: _angular_core.InputSignal<Date>;
    maxDate: _angular_core.InputSignal<Date>;
    disabled: _angular_core.InputSignal<boolean>;
    readonly: _angular_core.InputSignal<boolean>;
    required: _angular_core.InputSignal<boolean>;
    error: _angular_core.InputSignal<string | null>;
    requiredMessage: _angular_core.InputSignal<string>;
    name: _angular_core.InputSignal<string>;
    width: _angular_core.InputSignal<string>;
    maxWidth: _angular_core.InputSignal<string>;
    height: _angular_core.InputSignal<string>;
    maxHeight: _angular_core.InputSignal<string>;
    protected readonly errorId: string;
    protected readonly hasRequiredError: _angular_core.Signal<boolean>;
    protected readonly showError: _angular_core.Signal<boolean>;
    protected readonly displayedError: _angular_core.Signal<string>;
    protected readonly formattedValue: _angular_core.Signal<string>;
    protected selectDate(date: Date | null): void;
    protected clearOnKeydown(event: KeyboardEvent): void;
    protected markAsTouched(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpInputDatePicker, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpInputDatePicker, "tp-input-date-picker", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "errors": { "alias": "errors"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "dateFormat": { "alias": "dateFormat"; "required": false; "isSignal": true; }; "minDate": { "alias": "minDate"; "required": false; "isSignal": true; }; "maxDate": { "alias": "maxDate"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "requiredMessage": { "alias": "requiredMessage"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "maxWidth": { "alias": "maxWidth"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "maxHeight": { "alias": "maxHeight"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "touched": "touchedChange"; }, never, never, true, never>;
}

declare class TpDialog {
    open: _angular_core.ModelSignal<boolean>;
    title: _angular_core.InputSignal<string>;
    ariaLabel: _angular_core.InputSignal<string | null>;
    color: _angular_core.InputSignal<string>;
    textColor: _angular_core.InputSignal<string>;
    borderColor: _angular_core.InputSignal<string>;
    width: _angular_core.InputSignal<string>;
    maxWidth: _angular_core.InputSignal<string>;
    height: _angular_core.InputSignal<string>;
    maxHeight: _angular_core.InputSignal<string>;
    closeOnBackdrop: _angular_core.InputSignal<boolean>;
    closeOnEscape: _angular_core.InputSignal<boolean>;
    onOpen: _angular_core.OutputEmitterRef<void>;
    onClose: _angular_core.OutputEmitterRef<void>;
    protected readonly isOpen: _angular_core.ModelSignal<boolean>;
    protected readonly dialogStyle: _angular_core.Signal<{
        '--tp-dialog-color': string;
        '--tp-dialog-text-color': string;
        '--tp-dialog-border-color': string;
        width: string;
        maxWidth: string;
        height: string;
        maxHeight: string;
    }>;
    openDialog(): void;
    closeDialog(): void;
    protected handleBackdropClick(event: MouseEvent): void;
    protected handleEscape(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpDialog, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpDialog, "tp-dialog", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "textColor": { "alias": "textColor"; "required": false; "isSignal": true; }; "borderColor": { "alias": "borderColor"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "maxWidth": { "alias": "maxWidth"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "maxHeight": { "alias": "maxHeight"; "required": false; "isSignal": true; }; "closeOnBackdrop": { "alias": "closeOnBackdrop"; "required": false; "isSignal": true; }; "closeOnEscape": { "alias": "closeOnEscape"; "required": false; "isSignal": true; }; }, { "open": "openChange"; "onOpen": "onOpen"; "onClose": "onClose"; }, never, ["*", "[dialog-actions]"], true, never>;
}

type TpInputVariant = 'text' | 'number';
type TpInputValue = string | number | null;
type TpInputContentSize = 'sm' | 'md' | 'lg';
declare class TpInput implements FormValueControl<TpInputValue> {
    value: _angular_core.ModelSignal<TpInputValue>;
    touched: _angular_core.ModelSignal<boolean>;
    errors: _angular_core.InputSignal<TpValidationErrors>;
    invalid: _angular_core.InputSignal<boolean>;
    variant: _angular_core.InputSignal<TpInputVariant>;
    title: _angular_core.InputSignal<string>;
    placeholder: _angular_core.InputSignal<string>;
    required: _angular_core.InputSignal<boolean>;
    disabled: _angular_core.InputSignal<boolean>;
    readonly: _angular_core.InputSignal<boolean>;
    name: _angular_core.InputSignal<string>;
    autocomplete: _angular_core.InputSignal<string | null>;
    min: _angular_core.InputSignal<number | undefined>;
    max: _angular_core.InputSignal<number | undefined>;
    step: _angular_core.InputSignal<number | undefined>;
    hint: _angular_core.InputSignal<string | null>;
    error: _angular_core.InputSignal<string | null>;
    requiredMessage: _angular_core.InputSignal<string>;
    width: _angular_core.InputSignal<string>;
    maxWidth: _angular_core.InputSignal<string>;
    height: _angular_core.InputSignal<string>;
    maxHeight: _angular_core.InputSignal<string>;
    contentSize: _angular_core.InputSignal<TpInputContentSize>;
    protected readonly inputType: _angular_core.Signal<"number" | "text">;
    protected readonly inputValue: _angular_core.Signal<string | number>;
    protected readonly contentFontSize: _angular_core.Signal<string>;
    protected readonly isEmpty: _angular_core.Signal<boolean>;
    protected readonly hasRequiredError: _angular_core.Signal<boolean>;
    protected readonly errorId: string;
    protected readonly showError: _angular_core.Signal<boolean>;
    protected readonly displayedError: _angular_core.Signal<string>;
    protected updateValue(event: Event): void;
    protected markAsTouched(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpInput, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpInput, "tp-input", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "errors": { "alias": "errors"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "requiredMessage": { "alias": "requiredMessage"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "maxWidth": { "alias": "maxWidth"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "maxHeight": { "alias": "maxHeight"; "required": false; "isSignal": true; }; "contentSize": { "alias": "contentSize"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "touched": "touchedChange"; }, never, never, true, never>;
}

type TpAutocompleteSingleselectOption = string;
type TpInputAutocompleteSingleselectContentSize = 'sm' | 'md' | 'lg';
declare class TpInputAutocompleteSingleselect implements FormValueControl<string> {
    value: _angular_core.ModelSignal<string>;
    touched: _angular_core.ModelSignal<boolean>;
    errors: _angular_core.InputSignal<TpValidationErrors>;
    invalid: _angular_core.InputSignal<boolean>;
    options: _angular_core.InputSignal<readonly string[]>;
    loading: _angular_core.InputSignal<boolean>;
    title: _angular_core.InputSignal<string>;
    placeholder: _angular_core.InputSignal<string>;
    required: _angular_core.InputSignal<boolean>;
    disabled: _angular_core.InputSignal<boolean>;
    readonly: _angular_core.InputSignal<boolean>;
    name: _angular_core.InputSignal<string>;
    autocomplete: _angular_core.InputSignal<string | null>;
    ariaLabel: _angular_core.InputSignal<string | null>;
    hint: _angular_core.InputSignal<string | null>;
    error: _angular_core.InputSignal<string | null>;
    requiredMessage: _angular_core.InputSignal<string>;
    width: _angular_core.InputSignal<string>;
    maxWidth: _angular_core.InputSignal<string>;
    height: _angular_core.InputSignal<string>;
    maxHeight: _angular_core.InputSignal<string>;
    contentSize: _angular_core.InputSignal<TpInputAutocompleteSingleselectContentSize>;
    private readonly suggestionsTrigger;
    private readonly scrollDispatcher;
    private readonly destroyRef;
    constructor();
    protected readonly query: _angular_core.Signal<string>;
    protected readonly filteredOptions: _angular_core.Signal<string[]>;
    protected readonly contentFontSize: _angular_core.Signal<string>;
    protected readonly isEmpty: _angular_core.Signal<boolean>;
    protected readonly hasRequiredError: _angular_core.Signal<boolean>;
    protected readonly errorId: string;
    protected readonly showError: _angular_core.Signal<boolean>;
    protected readonly displayedError: _angular_core.Signal<string>;
    protected updateValue(event: Event): void;
    protected selectOption(event: MatAutocompleteSelectedEvent): void;
    protected markAsTouched(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpInputAutocompleteSingleselect, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpInputAutocompleteSingleselect, "tp-input-autocomplete-singleselect", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "errors": { "alias": "errors"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "requiredMessage": { "alias": "requiredMessage"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "maxWidth": { "alias": "maxWidth"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "maxHeight": { "alias": "maxHeight"; "required": false; "isSignal": true; }; "contentSize": { "alias": "contentSize"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "touched": "touchedChange"; }, never, never, true, never>;
}

type TpAutocompleteMultiselectOption = string;
type TpInputAutocompleteMultiselectContentSize = 'sm' | 'md' | 'lg';
declare class TpInputAutocompleteMultiselect implements FormValueControl<string[]> {
    value: _angular_core.ModelSignal<string[]>;
    touched: _angular_core.ModelSignal<boolean>;
    errors: _angular_core.InputSignal<TpValidationErrors>;
    invalid: _angular_core.InputSignal<boolean>;
    options: _angular_core.InputSignal<readonly string[]>;
    loading: _angular_core.InputSignal<boolean>;
    title: _angular_core.InputSignal<string>;
    placeholder: _angular_core.InputSignal<string>;
    required: _angular_core.InputSignal<boolean>;
    disabled: _angular_core.InputSignal<boolean>;
    readonly: _angular_core.InputSignal<boolean>;
    name: _angular_core.InputSignal<string>;
    autocomplete: _angular_core.InputSignal<string | null>;
    ariaLabel: _angular_core.InputSignal<string | null>;
    hint: _angular_core.InputSignal<string | null>;
    error: _angular_core.InputSignal<string | null>;
    requiredMessage: _angular_core.InputSignal<string>;
    width: _angular_core.InputSignal<string>;
    maxWidth: _angular_core.InputSignal<string>;
    minHeight: _angular_core.InputSignal<string>;
    maxHeight: _angular_core.InputSignal<string>;
    contentSize: _angular_core.InputSignal<TpInputAutocompleteMultiselectContentSize>;
    maxChipContentLength: _angular_core.InputSignal<number | undefined>;
    maxChips: _angular_core.InputSignal<number | undefined>;
    protected readonly selectAllOptionValue = "__tp-input-autocomplete-multiselect-select-all__";
    private readonly destroyRef;
    private readonly scrollDispatcher;
    private readonly optionsTrigger;
    private readonly triggerInput;
    private readonly searchQuery;
    protected readonly optionsOpen: _angular_core.WritableSignal<boolean>;
    private panelPositionUpdateQueued;
    private panelPositionTimeout;
    constructor();
    protected readonly selectedValues: _angular_core.Signal<string[]>;
    protected readonly visibleSelectedValues: _angular_core.Signal<string[]>;
    protected readonly hiddenSelectedCount: _angular_core.Signal<number>;
    protected readonly filteredOptions: _angular_core.Signal<string[]>;
    protected readonly allFilteredOptionsSelected: _angular_core.Signal<boolean>;
    protected readonly someFilteredOptionsSelected: _angular_core.Signal<boolean>;
    protected readonly selectAllLabel: _angular_core.Signal<"Unselect all" | "Select all">;
    protected readonly contentFontSize: _angular_core.Signal<string>;
    protected readonly floatLabel: _angular_core.Signal<"auto" | "always">;
    protected readonly isEmpty: _angular_core.Signal<boolean>;
    protected readonly hasRequiredError: _angular_core.Signal<boolean>;
    protected readonly errorId: string;
    protected readonly showError: _angular_core.Signal<boolean>;
    protected readonly displayedError: _angular_core.Signal<string>;
    protected updateQuery(event: Event): void;
    protected selectOption(event: MatAutocompleteSelectedEvent): void;
    protected toggleOptionFromPointer(option: TpAutocompleteMultiselectOption, event: MouseEvent): void;
    protected removeOption(option: TpAutocompleteMultiselectOption, event: MouseEvent): void;
    protected clearAll(event: MouseEvent): void;
    protected openOptions(event?: Event): void;
    protected toggleOptions(event?: Event): void;
    protected setOptionsOpen(open: boolean): void;
    protected markAsTouched(): void;
    protected isSelected(option: TpAutocompleteMultiselectOption): boolean;
    protected chipText(value: string): string;
    private toggleOption;
    private toggleAllFilteredOptions;
    protected readonly uniqueOptions: _angular_core.Signal<string[]>;
    private clearSearch;
    private reopenOptions;
    private updatePanelPosition;
    private cancelPendingCallbacks;
    private clearPanelPositionTimeout;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpInputAutocompleteMultiselect, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpInputAutocompleteMultiselect, "tp-input-autocomplete-multiselect", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "errors": { "alias": "errors"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "requiredMessage": { "alias": "requiredMessage"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "maxWidth": { "alias": "maxWidth"; "required": false; "isSignal": true; }; "minHeight": { "alias": "minHeight"; "required": false; "isSignal": true; }; "maxHeight": { "alias": "maxHeight"; "required": false; "isSignal": true; }; "contentSize": { "alias": "contentSize"; "required": false; "isSignal": true; }; "maxChipContentLength": { "alias": "maxChipContentLength"; "required": false; "isSignal": true; }; "maxChips": { "alias": "maxChips"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "touched": "touchedChange"; }, never, never, true, never>;
}

type TpSingleselectOption = string;
type TpInputSingleselectContentSize = 'sm' | 'md' | 'lg';
declare class TpInputSingleselect implements FormValueControl<string | null> {
    value: _angular_core.ModelSignal<string | null>;
    touched: _angular_core.ModelSignal<boolean>;
    errors: _angular_core.InputSignal<TpValidationErrors>;
    invalid: _angular_core.InputSignal<boolean>;
    options: _angular_core.InputSignal<readonly string[]>;
    loading: _angular_core.InputSignal<boolean>;
    title: _angular_core.InputSignal<string>;
    placeholder: _angular_core.InputSignal<string>;
    required: _angular_core.InputSignal<boolean>;
    disabled: _angular_core.InputSignal<boolean>;
    readonly: _angular_core.InputSignal<boolean>;
    name: _angular_core.InputSignal<string>;
    ariaLabel: _angular_core.InputSignal<string | null>;
    hint: _angular_core.InputSignal<string | null>;
    error: _angular_core.InputSignal<string | null>;
    requiredMessage: _angular_core.InputSignal<string>;
    width: _angular_core.InputSignal<string>;
    maxWidth: _angular_core.InputSignal<string>;
    height: _angular_core.InputSignal<string>;
    maxHeight: _angular_core.InputSignal<string>;
    contentSize: _angular_core.InputSignal<TpInputSingleselectContentSize>;
    private readonly select;
    private readonly scrollDispatcher;
    private readonly destroyRef;
    constructor();
    protected readonly contentFontSize: _angular_core.Signal<string>;
    protected readonly isEmpty: _angular_core.Signal<boolean>;
    protected readonly hasRequiredError: _angular_core.Signal<boolean>;
    protected readonly errorId: string;
    protected readonly showError: _angular_core.Signal<boolean>;
    protected readonly displayedError: _angular_core.Signal<string>;
    protected selectOption(event: MatSelectChange): void;
    protected clearValue(event: MouseEvent): void;
    protected markAsTouched(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpInputSingleselect, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpInputSingleselect, "tp-input-singleselect", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "errors": { "alias": "errors"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "requiredMessage": { "alias": "requiredMessage"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "maxWidth": { "alias": "maxWidth"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "maxHeight": { "alias": "maxHeight"; "required": false; "isSignal": true; }; "contentSize": { "alias": "contentSize"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "touched": "touchedChange"; }, never, never, true, never>;
}

type TpMultiselectOption = string;
type TpInputMultiselectContentSize = 'sm' | 'md' | 'lg';
declare class TpInputMultiselect implements FormValueControl<string[]> {
    value: _angular_core.ModelSignal<string[]>;
    touched: _angular_core.ModelSignal<boolean>;
    errors: _angular_core.InputSignal<TpValidationErrors>;
    invalid: _angular_core.InputSignal<boolean>;
    options: _angular_core.InputSignal<readonly string[]>;
    loading: _angular_core.InputSignal<boolean>;
    title: _angular_core.InputSignal<string>;
    placeholder: _angular_core.InputSignal<string>;
    required: _angular_core.InputSignal<boolean>;
    disabled: _angular_core.InputSignal<boolean>;
    readonly: _angular_core.InputSignal<boolean>;
    name: _angular_core.InputSignal<string>;
    ariaLabel: _angular_core.InputSignal<string | null>;
    hint: _angular_core.InputSignal<string | null>;
    error: _angular_core.InputSignal<string | null>;
    requiredMessage: _angular_core.InputSignal<string>;
    width: _angular_core.InputSignal<string>;
    maxWidth: _angular_core.InputSignal<string>;
    minHeight: _angular_core.InputSignal<string>;
    maxHeight: _angular_core.InputSignal<string>;
    contentSize: _angular_core.InputSignal<TpInputMultiselectContentSize>;
    maxChipContentLength: _angular_core.InputSignal<number | undefined>;
    maxChips: _angular_core.InputSignal<number | undefined>;
    protected readonly selectAllOptionValue = "__tp-input-multiselect-select-all__";
    private readonly destroyRef;
    private readonly scrollDispatcher;
    private readonly optionsTrigger;
    private readonly triggerInput;
    protected readonly optionsOpen: _angular_core.WritableSignal<boolean>;
    private panelPositionUpdateQueued;
    private panelPositionTimeout;
    constructor();
    protected readonly selectedValues: _angular_core.Signal<string[]>;
    protected readonly visibleSelectedValues: _angular_core.Signal<string[]>;
    protected readonly hiddenSelectedCount: _angular_core.Signal<number>;
    protected readonly allSelected: _angular_core.Signal<boolean>;
    protected readonly someSelected: _angular_core.Signal<boolean>;
    protected readonly selectAllLabel: _angular_core.Signal<"Unselect all" | "Select all">;
    protected readonly contentFontSize: _angular_core.Signal<string>;
    protected readonly floatLabel: _angular_core.Signal<"auto" | "always">;
    protected readonly isEmpty: _angular_core.Signal<boolean>;
    protected readonly hasRequiredError: _angular_core.Signal<boolean>;
    protected readonly errorId: string;
    protected readonly showError: _angular_core.Signal<boolean>;
    protected readonly displayedError: _angular_core.Signal<string>;
    protected selectOption(event: MatAutocompleteSelectedEvent): void;
    protected toggleOptionFromPointer(option: TpMultiselectOption, event: MouseEvent): void;
    protected removeOption(option: TpMultiselectOption, event: MouseEvent): void;
    protected clearAll(event: MouseEvent): void;
    protected openOptions(event?: Event): void;
    protected toggleOptions(event?: Event): void;
    protected setOptionsOpen(open: boolean): void;
    protected markAsTouched(): void;
    protected isSelected(option: TpMultiselectOption): boolean;
    protected chipText(value: string): string;
    private toggleOption;
    private toggleAll;
    protected readonly uniqueOptions: _angular_core.Signal<string[]>;
    private clearTriggerValue;
    private reopenOptions;
    private updatePanelPosition;
    private cancelPendingCallbacks;
    private clearPanelPositionTimeout;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpInputMultiselect, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpInputMultiselect, "tp-input-multiselect", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "errors": { "alias": "errors"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "requiredMessage": { "alias": "requiredMessage"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "maxWidth": { "alias": "maxWidth"; "required": false; "isSignal": true; }; "minHeight": { "alias": "minHeight"; "required": false; "isSignal": true; }; "maxHeight": { "alias": "maxHeight"; "required": false; "isSignal": true; }; "contentSize": { "alias": "contentSize"; "required": false; "isSignal": true; }; "maxChipContentLength": { "alias": "maxChipContentLength"; "required": false; "isSignal": true; }; "maxChips": { "alias": "maxChips"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "touched": "touchedChange"; }, never, never, true, never>;
}

declare class TpRadio {
    checked: _angular_core.ModelSignal<boolean>;
    touched: _angular_core.ModelSignal<boolean>;
    disabled: _angular_core.InputSignal<boolean>;
    required: _angular_core.InputSignal<boolean>;
    name: _angular_core.InputSignal<string>;
    value: _angular_core.InputSignal<unknown>;
    ariaLabel: _angular_core.InputSignal<string | null>;
    protected updateChecked(event: MatRadioChange): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpRadio, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpRadio, "tp-radio", never, { "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, { "checked": "checkedChange"; "touched": "touchedChange"; }, never, ["*"], true, never>;
}

declare class TpSearchBar {
    width: _angular_core.InputSignal<string>;
    maxWidth: _angular_core.InputSignal<string>;
    placeholder: _angular_core.InputSignal<string>;
    ariaLabel: _angular_core.InputSignal<string>;
    searchAfter: _angular_core.InputSignal<number>;
    onSearch: _angular_core.OutputEmitterRef<string>;
    private readonly searchModel;
    protected readonly searchField: _angular_forms_signals.FieldTree<string, string | number>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpSearchBar, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpSearchBar, "tp-search-bar", never, { "width": { "alias": "width"; "required": false; "isSignal": true; }; "maxWidth": { "alias": "maxWidth"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "searchAfter": { "alias": "searchAfter"; "required": false; "isSignal": true; }; }, { "onSearch": "onSearch"; }, never, never, true, never>;
}

type TpSkeletonVariant = 'text' | 'circle' | 'rectangle';
declare class TpSkeleton {
    variant: _angular_core.InputSignal<TpSkeletonVariant>;
    width: _angular_core.InputSignal<string | null>;
    height: _angular_core.InputSignal<string | null>;
    protected readonly skeletonClass: _angular_core.Signal<{
        [x: string]: boolean;
    }>;
    protected readonly skeletonStyle: _angular_core.Signal<{
        width: string;
        height: string;
    }>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpSkeleton, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpSkeleton, "tp-skeleton", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type TpSpinnerColor = TpComponentColor;
declare class TpSpinner {
    color: _angular_core.InputSignal<"gray" | "red" | "pink" | "amber" | "orange" | "yellow" | "green" | "emerald" | "teal" | "blue" | "cyan" | "purple" | "violet" | "indigo">;
    diameter: _angular_core.InputSignalWithTransform<number, unknown>;
    strokeWidth: _angular_core.InputSignalWithTransform<number, unknown>;
    ariaLabel: _angular_core.InputSignal<string>;
    protected readonly spinnerStyle: _angular_core.Signal<{
        '--tp-spinner-color': string;
    }>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpSpinner, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpSpinner, "tp-spinner", never, { "color": { "alias": "color"; "required": false; "isSignal": true; }; "diameter": { "alias": "diameter"; "required": false; "isSignal": true; }; "strokeWidth": { "alias": "strokeWidth"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type TpTextButtonColor = 'gray' | 'white' | 'black';
type TpTextButtonAfterPressEffect = 'underline' | 'none';
type TpTextButtonPressEffectShape = 'circle' | 'elip' | 'rect';
type TpTextButtonContentAlignment = 'start' | 'center' | 'end';
declare class TpTextButton {
    color: _angular_core.InputSignal<TpTextButtonColor>;
    afterPressEffect: _angular_core.InputSignal<TpTextButtonAfterPressEffect>;
    pressEffectShape: _angular_core.InputSignal<TpTextButtonPressEffectShape>;
    hoverShape: _angular_core.InputSignal<TpTextButtonPressEffectShape | undefined>;
    contentAlignment: _angular_core.InputSignal<TpTextButtonContentAlignment>;
    disabled: _angular_core.InputSignal<boolean>;
    fullWidth: _angular_core.InputSignal<boolean>;
    tooltipTitle: _angular_core.InputSignal<string | null>;
    width: _angular_core.InputSignal<string>;
    maxWidth: _angular_core.InputSignal<string>;
    height: _angular_core.InputSignal<string>;
    maxHeight: _angular_core.InputSignal<string>;
    fontSize: _angular_core.InputSignal<string>;
    fontWeight: _angular_core.InputSignal<string>;
    onClick: _angular_core.OutputEmitterRef<MouseEvent>;
    protected readonly textButtonStyle: _angular_core.Signal<{
        '--tp-text-button-color': string;
        width: string;
        maxWidth: string;
        height: string;
        maxHeight: string;
        fontSize: string;
        fontWeight: string;
    }>;
    protected readonly textButtonClass: _angular_core.Signal<{
        [x: string]: boolean;
        'tp-text-button--underline': boolean;
    }>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpTextButton, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpTextButton, "tp-text-button", never, { "color": { "alias": "color"; "required": false; "isSignal": true; }; "afterPressEffect": { "alias": "afterPressEffect"; "required": false; "isSignal": true; }; "pressEffectShape": { "alias": "pressEffectShape"; "required": false; "isSignal": true; }; "hoverShape": { "alias": "hoverShape"; "required": false; "isSignal": true; }; "contentAlignment": { "alias": "contentAlignment"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; "tooltipTitle": { "alias": "tooltipTitle"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "maxWidth": { "alias": "maxWidth"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "maxHeight": { "alias": "maxHeight"; "required": false; "isSignal": true; }; "fontSize": { "alias": "fontSize"; "required": false; "isSignal": true; }; "fontWeight": { "alias": "fontWeight"; "required": false; "isSignal": true; }; }, { "onClick": "onClick"; }, never, ["*"], true, never>;
}

declare class TpTextArea implements FormValueControl<string> {
    value: _angular_core.ModelSignal<string>;
    touched: _angular_core.ModelSignal<boolean>;
    errors: _angular_core.InputSignal<TpValidationErrors>;
    invalid: _angular_core.InputSignal<boolean>;
    title: _angular_core.InputSignal<string>;
    placeholder: _angular_core.InputSignal<string>;
    required: _angular_core.InputSignal<boolean>;
    disabled: _angular_core.InputSignal<boolean>;
    readonly: _angular_core.InputSignal<boolean>;
    name: _angular_core.InputSignal<string>;
    rows: _angular_core.InputSignalWithTransform<number, unknown>;
    maxLength: _angular_core.InputSignal<number | undefined>;
    hint: _angular_core.InputSignal<string | null>;
    error: _angular_core.InputSignal<string | null>;
    requiredMessage: _angular_core.InputSignal<string>;
    width: _angular_core.InputSignal<string>;
    maxWidth: _angular_core.InputSignal<string>;
    protected readonly hasCharacterLimit: _angular_core.Signal<boolean>;
    protected readonly characterCount: _angular_core.Signal<number>;
    protected readonly isEmpty: _angular_core.Signal<boolean>;
    protected readonly hasRequiredError: _angular_core.Signal<boolean>;
    protected readonly errorId: string;
    protected readonly showError: _angular_core.Signal<boolean>;
    protected readonly displayedError: _angular_core.Signal<string>;
    protected updateValue(event: Event): void;
    protected markAsTouched(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpTextArea, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpTextArea, "tp-text-area", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "errors": { "alias": "errors"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "maxLength": { "alias": "maxLength"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "requiredMessage": { "alias": "requiredMessage"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "maxWidth": { "alias": "maxWidth"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "touched": "touchedChange"; }, never, never, true, never>;
}

type TpTableCellValue = string | number | boolean | Date | null | undefined;
type TpTableSortDirection = 'asc' | 'desc';
type TpTableDataMode = 'client' | 'server';
interface TpTableColumn<T extends object> {
    /** A unique identifier and, by default, the property read from each row. */
    key: string;
    /** Text displayed in the header. */
    title: string;
    /** Returns the value displayed for the cell when the value is not a direct row property. */
    value?: (row: T) => TpTableCellValue;
    /** Enables the sort control in this column header. */
    sortable?: boolean;
    /** Returns the value used by the built-in client-side sorter. */
    sortValue?: (row: T) => TpTableCellValue;
    /** Replaces the built-in client-side sort comparison for this column. */
    sortFn?: (left: T, right: T) => number;
    /** Optional CSS width for the column, for example `12rem`. */
    width?: string;
    /** Optional CSS minimum width for the column, for example `10rem`. */
    minWidth?: string;
    /** Overrides maxCellContentLength for this column. */
    maxCellContentLength?: number;
}
interface TpTableSort {
    key: string;
    direction: TpTableSortDirection;
}
interface TpTablePageChange {
    page: number;
    pageSize: number;
}
interface TpTableData<T extends object = Record<string, unknown>> {
    /** The rows to display. */
    rows: readonly T[];
    /** Use `server` when sorting and pagination are performed outside the component. */
    dataMode?: TpTableDataMode;
    /** Total number of rows in server mode. */
    totalRows?: number | null;
}
interface TpTableFilterConfig {
    /** Adds a filter row below the column headers. */
    enabled?: boolean;
}
interface TpTableSortConfig {
    /** Enables sort controls for sortable columns. */
    enabled?: boolean;
    /** Initial or externally controlled sort. */
    value?: TpTableSort | null;
}
interface TpTablePaginationConfig {
    enabled?: boolean;
    /** The active page, starting at 1. */
    page?: number;
    /** The number of rows per page. */
    pageSize?: number;
    pageSizeOptions?: readonly number[];
    pageSizeTitle?: string;
    goToPageTitle?: string;
    /** Disables the previous-page button while data is pending. */
    prevPageButtonDisabled?: boolean;
    /** Disables the next-page button while data is pending. */
    nextPageButtonDisabled?: boolean;
}
interface TpTableReloadConfig {
    enabled?: boolean;
    title?: string;
    /** Disables the reload icon while data is pending. */
    buttonDisabled?: boolean;
}
interface TpTableConfig<T extends object = Record<string, unknown>> {
    columns: readonly TpTableColumn<T>[];
    rowHeight?: string | number;
    maxWidth?: string;
    maxHeight?: string | number;
    maxCellContentLength?: number;
    rowsClickable?: boolean;
    rowTrackBy?: (row: T, index: number) => unknown;
    filter?: TpTableFilterConfig;
    sort?: TpTableSortConfig;
    pagination?: TpTablePaginationConfig;
    reload?: TpTableReloadConfig;
}
interface TpTableLoadingState {
    enabled?: boolean;
}
interface TpTableState {
    loading?: TpTableLoadingState;
}
interface TpTableActionColumnConfig {
    enabled?: boolean;
    title?: string;
    menuWidth?: string | number;
    menuHeight?: string | number;
}
interface TpTableActionContentContext<T extends object> {
    $implicit: T;
    row: T;
}
interface TpTableFilterContentContext<T extends object> {
    /** The column whose filter cell is being rendered. */
    $implicit: TpTableColumn<T>;
    column: TpTableColumn<T>;
    key: string;
}
interface TpTableEmptyContentContext<T extends object> {
    /** The rows currently supplied to the table (usually an empty collection). */
    $implicit: readonly T[];
    rows: readonly T[];
    columns: readonly TpTableColumn<T>[];
    colSpan: number;
}
/**
 * Marks a projected action-menu template. Its implicit value and `row` local
 * are the row whose Actions button opened the menu.
 */
declare class TpTableActionContent<T extends object = Record<string, unknown>> {
    readonly template: TemplateRef<TpTableActionContentContext<T>>;
    constructor(template: TemplateRef<TpTableActionContentContext<T>>);
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpTableActionContent<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TpTableActionContent<any>, "ng-template[tpTableActionContent]", never, {}, {}, never, never, true, never>;
}
/**
 * Marks a projected filter template. When `tpTableFilter` has a value, the
 * template is used for the matching column key. A template without a value is
 * used as the fallback for every column that has no keyed template.
 */
declare class TpTableFilterContent<T extends object = Record<string, unknown>> {
    readonly template: TemplateRef<TpTableFilterContentContext<T>>;
    readonly key: _angular_core.InputSignal<string | null>;
    constructor(template: TemplateRef<TpTableFilterContentContext<T>>);
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpTableFilterContent<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TpTableFilterContent<any>, "ng-template[tpTableFilter]", never, { "key": { "alias": "tpTableFilter"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/** Marks a projected template used instead of the default empty message. */
declare class TpTableEmptyContent<T extends object = Record<string, unknown>> {
    readonly template: TemplateRef<TpTableEmptyContentContext<T>>;
    constructor(template: TemplateRef<TpTableEmptyContentContext<T>>);
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpTableEmptyContent<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TpTableEmptyContent<any>, "ng-template[tpTableEmpty]", never, {}, {}, never, never, true, never>;
}
/** A configurable table with client- or server-driven pagination and sorting. */
declare class TpTable<T extends object = Record<string, unknown>> {
    /** The table rows and data-mode metadata. */
    data: _angular_core.InputSignal<TpTableData<T>>;
    /** Visual and interaction configuration, including columns and feature settings. */
    config: _angular_core.InputSignal<TpTableConfig<T>>;
    /** Runtime state such as loading. */
    state: _angular_core.InputSignal<TpTableState>;
    /** Configuration for the optional action column. */
    actionColumn: _angular_core.InputSignal<TpTableActionColumnConfig>;
    /** Emits both the selected page and page size after a user pagination action. */
    onPaginationChange: _angular_core.OutputEmitterRef<TpTablePageChange>;
    /** Emits when the reload icon is clicked. */
    onReload: _angular_core.OutputEmitterRef<void>;
    /** Emits when a sortable column is selected. */
    onSortChange: _angular_core.OutputEmitterRef<TpTableSort | null>;
    onRowClick: _angular_core.OutputEmitterRef<T>;
    private readonly page;
    private readonly pageSize;
    private readonly sort;
    private configuredPage;
    private configuredPageSize;
    private configuredSort;
    private readonly configuredStateEffect;
    protected readonly currentActionRow: _angular_core.WritableSignal<T | null>;
    protected readonly actionContent: _angular_core.Signal<TpTableActionContent<T> | undefined>;
    protected readonly filterContents: _angular_core.Signal<readonly TpTableFilterContent<T>[]>;
    protected readonly emptyContent: _angular_core.Signal<TpTableEmptyContent<T> | undefined>;
    protected readonly columns: _angular_core.Signal<readonly TpTableColumn<T>[]>;
    protected readonly rows: _angular_core.Signal<readonly T[]>;
    protected readonly dataMode: _angular_core.Signal<TpTableDataMode>;
    protected readonly filterEnabled: _angular_core.Signal<boolean>;
    protected readonly sortEnabled: _angular_core.Signal<boolean>;
    protected readonly paginationEnabled: _angular_core.Signal<boolean>;
    protected readonly pageSizeOptions: _angular_core.Signal<readonly number[]>;
    protected readonly pageSizeTitle: _angular_core.Signal<string>;
    protected readonly goToPageTitle: _angular_core.Signal<string>;
    protected readonly reloadEnabled: _angular_core.Signal<boolean>;
    protected readonly reloadTitle: _angular_core.Signal<string>;
    protected readonly reloadButtonDisabled: _angular_core.Signal<boolean>;
    protected readonly prevPageButtonDisabled: _angular_core.Signal<boolean>;
    protected readonly nextPageButtonDisabled: _angular_core.Signal<boolean>;
    protected readonly maxWidth: _angular_core.Signal<string>;
    protected readonly maxCellContentLength: _angular_core.Signal<number>;
    protected readonly rowsClickable: _angular_core.Signal<boolean>;
    protected readonly rowTrackBy: _angular_core.Signal<(row: T, index: number) => unknown>;
    protected readonly loading: _angular_core.Signal<boolean>;
    protected readonly actionsEnabled: _angular_core.Signal<boolean>;
    protected readonly actionTitle: _angular_core.Signal<string>;
    protected readonly rowHeightCss: _angular_core.Signal<string>;
    protected readonly maxHeightCss: _angular_core.Signal<string>;
    protected readonly actionMenuWidthCss: _angular_core.Signal<string>;
    protected readonly actionMenuHeightCss: _angular_core.Signal<string>;
    protected readonly columnSpan: _angular_core.Signal<number>;
    protected readonly totalRowCount: _angular_core.Signal<number>;
    protected readonly validPageSize: _angular_core.Signal<number>;
    protected readonly pageCount: _angular_core.Signal<number>;
    protected readonly currentPage: _angular_core.Signal<number>;
    protected readonly sortedRows: _angular_core.Signal<readonly T[]>;
    protected readonly displayedRows: _angular_core.Signal<readonly T[]>;
    protected readonly rowRange: _angular_core.Signal<{
        from: number;
        to: number;
    }>;
    protected readonly goToPageOptions: _angular_core.Signal<number[]>;
    protected readonly resolvedPageSizeOptions: _angular_core.Signal<number[]>;
    protected toggleSort(column: TpTableColumn<T>): void;
    protected sortIcon(column: TpTableColumn<T>): string;
    protected isSorted(column: TpTableColumn<T>): boolean;
    protected columnAriaSort(column: TpTableColumn<T>): 'ascending' | 'descending' | 'none' | null;
    protected previousPage(): void;
    protected nextPage(): void;
    protected selectPage(event: MatSelectChange): void;
    protected selectPageSize(event: MatSelectChange): void;
    protected rowText(row: T, column: TpTableColumn<T>): string;
    protected cellPresentation(row: T, column: TpTableColumn<T>): {
        fullText: string;
        displayText: string;
    };
    protected filterContentFor(column: TpTableColumn<T>): TpTableFilterContent<T> | undefined;
    protected emptyContentContext(): TpTableEmptyContentContext<T>;
    protected openActions(row: T, event: MouseEvent): void;
    protected activateRow(row: T): void;
    protected activateRowFromKeyboard(row: T, event: KeyboardEvent): void;
    protected trackRow(row: T, index: number): unknown;
    protected setPage(page: number): void;
    private compareRows;
    private cellValue;
    private compareValues;
    private clampPage;
    private toCssSize;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TpTable<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TpTable<any>, "tp-table", never, { "data": { "alias": "data"; "required": false; "isSignal": true; }; "config": { "alias": "config"; "required": false; "isSignal": true; }; "state": { "alias": "state"; "required": false; "isSignal": true; }; "actionColumn": { "alias": "actionColumn"; "required": false; "isSignal": true; }; }, { "onPaginationChange": "onPaginationChange"; "onReload": "onReload"; "onSortChange": "onSortChange"; "onRowClick": "onRowClick"; }, ["actionContent", "filterContents", "emptyContent"], never, true, never>;
}

export { TP_DEFAULT_MAX_DATE, TP_DEFAULT_MIN_DATE, TpAvatar, TpBellNotification, TpButton, TpCard, TpCheckbox, TpChip, TpDatePicker, TpDialog, TpInput, TpInputAutocompleteMultiselect, TpInputAutocompleteSingleselect, TpInputDatePicker, TpInputMultiselect, TpInputSingleselect, TpRadio, TpSearchBar, TpSkeleton, TpSpinner, TpTable, TpTableActionContent, TpTableEmptyContent, TpTableFilterContent, TpTextArea, TpTextButton, createTpDefaultMaxDate, createTpDefaultMinDate };
export type { TpAutocompleteMultiselectOption, TpAutocompleteSingleselectOption, TpButtonColor, TpChipColor, TpChipSize, TpChipVariant, TpDateFormat, TpInputAutocompleteMultiselectContentSize, TpInputAutocompleteSingleselectContentSize, TpInputContentSize, TpInputMultiselectContentSize, TpInputSingleselectContentSize, TpInputValue, TpInputVariant, TpMultiselectOption, TpSingleselectOption, TpSkeletonVariant, TpSpinnerColor, TpTableActionColumnConfig, TpTableActionContentContext, TpTableCellValue, TpTableColumn, TpTableConfig, TpTableData, TpTableDataMode, TpTableEmptyContentContext, TpTableFilterConfig, TpTableFilterContentContext, TpTableLoadingState, TpTablePageChange, TpTablePaginationConfig, TpTableReloadConfig, TpTableSort, TpTableSortConfig, TpTableSortDirection, TpTableState, TpTextButtonAfterPressEffect, TpTextButtonColor, TpTextButtonContentAlignment, TpTextButtonPressEffectShape };
